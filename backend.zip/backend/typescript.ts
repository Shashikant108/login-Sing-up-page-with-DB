const a=40;
let b = "kumar";
var c = "ravi singh";
var d:number=8000;
var f:any ="kumar";
let x = [];
let y:number[]=[10,20,30,20,450,50];
let u:string[]=["kumar","ravi","mohan"];
const p:any[]=[10,20,30,"kumar","oooo","abc"];
const w:[number,string,boolean,string]=[40,"kumar",true,"ravi"];

console.log(d);
console.log(typeof(d));


export default a