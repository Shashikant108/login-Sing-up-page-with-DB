function abc()
{
    alert("welcome to js link in nodejs");
}